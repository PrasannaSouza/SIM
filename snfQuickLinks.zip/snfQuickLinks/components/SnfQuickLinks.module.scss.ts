
require("./SnfQuickLinks.module.css");
const styles = {
  mainLayout: 'mainLayout_30ed66d9',
  leftSection: 'leftSection_30ed66d9',
  rightSection: 'rightSection_30ed66d9',
  quickLinks: 'quickLinks_30ed66d9',
  container: 'container_30ed66d9',
  header: 'header_30ed66d9',
  'header-box': 'header-box_30ed66d9',
  grid: 'grid_30ed66d9',
  card: 'card_30ed66d9',
  icon1: 'icon1_30ed66d9',
  icon: 'icon_30ed66d9',
  title1: 'title1_30ed66d9',
  title: 'title_30ed66d9',
  arrow: 'arrow_30ed66d9',
  teamBox: 'teamBox_30ed66d9',
  teamHeader: 'teamHeader_30ed66d9',
  teamIcon: 'teamIcon_30ed66d9',
  teamList: 'teamList_30ed66d9',
  teamCard1: 'teamCard1_30ed66d9',
  teamCard: 'teamCard_30ed66d9',
  avatar1: 'avatar1_30ed66d9',
  avatar: 'avatar_30ed66d9',
  teamInfo1: 'teamInfo1_30ed66d9',
  teamInfo: 'teamInfo_30ed66d9',
  mail1: 'mail1_30ed66d9',
  mail: 'mail_30ed66d9'
};

export default styles;
