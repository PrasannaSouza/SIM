import * as React from 'react';
import styles from './SnfQuickLinks.module.scss';
 

const links = [
  {
    title: 'Case for Change\nBackground & Introduction',
    icon: require('../assets/cforc.png')
  },
  {
    title: 'What is the Scientific\nNarrative Framework (SNF)?',
    icon: require('../assets/wts.png')
  },
  {
    title: 'Scientific Narrative\nFramework Implementation',
    icon: require('../assets/sn.png')
  },
  {
    title: 'Role-based SNF training',
    icon: require('../assets/rb.png')
  }
];

const members = [
  {
    name: 'Lindsey Burton',
    role: 'Designation goes here',
    img: require('../assets/team1.jpg')
  },
  {
    name: 'Joanna Gonsalves',
    role: 'Designation goes here',
    img: require('../assets/team2.jpg')
  }
];

const SnfQuickLinks: React.FC = () => {
  return (
    <section
      className={styles.quickLinks}
      style={{
        backgroundImage: `url(${require('../assets/bg-quicklinks.png')})`
      }}
    >

      {/* 🔥 MAIN LAYOUT */}
      <div className={styles.mainLayout}>

        {/* ✅ LEFT (75%)  */}
        <div className={styles.leftSection}>
          <div className={styles.container}>

            <div className={styles.header}>
              <div className={styles['header-box']}>
                <img src={require('../assets/quicklink.png')} />
              </div>
              <h3>Quicks Links</h3>
            </div>

            <div className={styles.grid}>
              {links.map((item, i) => (
                <div key={i} className={styles.card}>

                  <div className={styles.icon}>
                    <img src={item.icon} />
                  </div>

                  <p className={styles.title}>
                    {item.title}
                  </p>

                 

                </div>
              ))}
            </div>

          </div>
        </div>

        {/* ✅ RIGHT (25%) -  TEAM DESIGN */}
        <div className={styles.rightSection} >

          <div className={styles.teamBox}    >

            <div className={styles.teamHeader}>
              <div className={styles.teamIcon}>
                <img src={require('../assets/team-icon.png')} />
              </div>
              <h3>Meet The Team</h3>
            </div>

            <div className={styles.teamList}>
              {members.map((m, i) => (
                <div key={i} className={styles.teamCard}>

                  <img src={m.img} className={styles.avatar} />

                  <div className={styles.teamInfo}>
                    <h4>{m.name}</h4>
                    <p>{m.role}</p>
                  </div>

                  <div className={styles.mail}>
                    <img src={require('../assets/mail.svg')} />
                  </div>

                </div>
              ))}
            </div>

          </div>

        </div>

      </div>

    </section>
  );
};

export default SnfQuickLinks;